You may add additional ".tree" files to this folder and they will be merged into either the "minecraft.tree" file if it is in this folder or the normal InvTweakTree.txt file if "minecraft.tree" does not exist.  These tree files have the same structure as the InvTweakTree.txt file, and matching categories will be merged into one with nodes from the new tree file being added to the end of the matching category.

You can find tree files maintained by IMarvinTPA at https://github.com/IMarvinTPA/InventoryTweaksTrees


